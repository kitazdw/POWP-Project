# Laboratoria - zastosowanie wzorców projektowych w bibliotece narzędziowej PlotterMagic

## instrukcje

* powp-lab-adapter.pdf - Zapoznanie z projektem i warianty wzorca *adapter*
* powp-lab-command.pdf - Zastosowanie wzorca *command* i innych...

## ogólne zasady oceny pracy na laboratoriach

Rozwiązanie zadań laboratoryjnych zgłasza się za pomocą Pull Request. 
Podstawowy czas na wykonanie wszystkich zadań to 7 dni.
Za zgłoszone w terminie rozwiązanie pojedynczej instrukcji można dostać max. 5 pkt. 
Dodatkowe punkty mogą być przyznane za zadania z gwiazdką.
Za każdy tydzień opóźnienia maksymalna liczba punktów zmniejsza się o jeden.
Więcej obowiązujących informacji dotyczących pracy z repozytorium znajdują się w instrukcjach.
